# v1.3.2
## 05/xx/2017

1. [](#new)
    * Added option for line numbers

# v1.3.1
## 07/14/2016

1. [](#bugfix)
    * Fixed a typo in the Monokai theme name

# v1.3.0
## 01/22/2016

1. [](#new)
    * Updated `highlight.js` to version 9.1.0
1. [](#improved)
    * Use common language strings in blueprints

# v1.2.1
## 01/06/2016

1. [](#bugfix)
    * Fixed the example listed in the README

# v1.2.0
## 07/20/2015

1. [](#new)
    * Updated `highlight.js` to version 8.6.0
    * Added new themes

# v1.1.0
## 11/30/2014

1. [](#new)
    * ChangeLog started...
